OWL FLY III - embeddable browser build
======================================

Upload this whole folder to your web server (for example as /owlfly3/)
and embed the game on any page with:

  <iframe src="/owlfly3/owlfly3_embed.html"
          style="width:100%;aspect-ratio:4/3;border:0;background:#000"
          allow="fullscreen; gamepad; autoplay; cross-origin-isolated"
          allowfullscreen title="OWL FLY III"></iframe>

embed_example.html is a ready host page showing exactly that.

What is inside
  owlfly3_embed.html    the game page, made to fill an iframe
  owlfly3_v17.jsdos     the game itself (js-dos bundle)
  jsdos/                js-dos 8 - DOSBox compiled to WebAssembly
  owlcontrols.js        on-screen stick and buttons for phones
  coi-serviceworker.js  cross-origin isolation for static hosting

Multiplayer
  Built in. The game tunnels IPX through a WebSocket to our relay at
  wss://view.owlos.sk - nothing to install or host on your side.
  Every player in the same room meets in the same sky. Options:
    owlfly3_embed.html?room=yoursite     a private sky for your players
    owlfly3_embed.html?relay=wss://...   your own relay instead of ours

Notes
  - Serve it over http(s); opening the file from disk will not work.
  - Players click the game once to give it the keyboard.
  - Keep the tab visible: browsers pause hidden tabs.

Source and more: https://github.com/KirinDenis/wire-city-2
